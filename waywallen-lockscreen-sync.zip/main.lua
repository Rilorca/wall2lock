local M = {}

function M.info()
    return {
        name = "lockscreen_sync",
        display_name = tr("Lockscreen & SDDM Sync"),
        status = {
            {
                id = "lockscreen_status",
                label = tr("Lockscreen Sync"),
                order = 10,
            },
        },
        actions = {
            {
                id = "sync_action",
                kind = "invoke",
                label = tr("Sync Lockscreen"),
                order = 20,
            },
        },
        capabilities = {},
    }
end

M.actions = {}
function M.actions.status(ctx)
    return {
        status = {
            lockscreen_status = "Active",
        },
        actions = {
            sync_action = { visible = true, enabled = true },
        },
    }
end

function M.actions.invoke(ctx, action_id, values)
    if ctx and ctx.log then
        ctx.log("lockscreen_sync: action " .. tostring(action_id))
    end
end

return M
